package csv;

import java.util.List;

import pokemon.Attaque;

public interface Boules {
	
	public List<Attaque> getAttaque();
}
