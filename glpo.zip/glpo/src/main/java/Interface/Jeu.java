package Interface;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JFrame;

import csv.Boules;
import csv.csvAttaque;
import pokemon.Attaque;
import pokemon.Pokemon;



@SuppressWarnings({ "unused", "serial" })
public class Jeu extends Interface1 {

	
	
	public Jeu() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException{
		
		
			pokemon[0]=CreationPokemon();
			pokemon[1]=CreationPokemon();
			while (pokemon[1].nomPokemon==pokemon[0].nomPokemon)
			{
				pokemon[1]=CreationPokemon();
			}
			Interface1 fen = new Interface1();
			
		

	}
}

