package pokemon;

import static org.junit.Assert.*;

import org.junit.Test;

public class AttaqueTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
