package Interface;

import static org.junit.Assert.*;

import org.junit.Test;

public class Interface1Test {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
