package Interface;
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import csv.Boules;
import csv.csvAttaque;
import pokemon.Attaque;
import pokemon.Pokemon; 
//TODO 
//     COndition de victoire 
 

@SuppressWarnings({"serial", "unused", "deprecation"})
public class Interface1 extends JFrame implements ActionListener {
	
	private int action;
	public int anim= 0;
	protected static boolean run= true;
	private JPanel pan = new JPanel();
	private JPanel panel = new JPanel();
	private JButton atq1 = new JButton("Attaque de base");
	private JButton atq2 = new JButton("Soin");
	private JButton atq3 = new JButton("Reduc. Deg");
	private JButton atq4 = new JButton("Forte Attaque");
	private JButton atq5 = new JButton("Regen.Mana & Regen Atq");
	private int a=0, b=1, tmp;
	public static Pokemon [] pokemon = new Pokemon[2]; 
	private JLabel pv1=new JLabel("PV: " + pokemon[0].PV), pv2=new JLabel("PV: " + pokemon[1].PV);
	private JLabel type1, type2, faiblesse1, faiblesse2;
	private JLabel mana1=new JLabel("Mana: " + pokemon[0].mana), mana2=new JLabel("Mana: " + pokemon[0].mana), nom1, nom2 ;
	private JLabel tirage1= new JLabel("Tirage de "+ pokemon[0].nomPokemon+":  "+pokemon[0].attaques.attaque1 +"  -  " +pokemon[0].attaques.attaque2+"  -  " +pokemon[0].attaques.attaque3+"  -  " +pokemon[0].attaques.attaque4+"  -  " +pokemon[0].attaques.attaque5);
	private JLabel tirage2= new JLabel("Tirage de "+ pokemon[1].nomPokemon+":  "+pokemon[1].attaques.attaque1 +"  -  " +pokemon[1].attaques.attaque2+"  -  " +pokemon[1].attaques.attaque3+"  -  " +pokemon[1].attaques.attaque4+"  -  " +pokemon[1].attaques.attaque5);
	private JLabel actions =  new JLabel("");
	private JLabel tour = new JLabel("");
	private JTextArea describ1, describ2, describ3, describ4, describ5;
	private Color black;
	private Color white;
	JFrame fenetre = new JFrame();
	JOptionPane fin;
	
	
	public static Pokemon CreationPokemon(){
		Pokemon pokemonA;
		String [] listePokemon = new String[11];
		Random rand = new Random();
		int id1; /*Correspondra aux �toiles CSV*/
		
		
		listePokemon[0]="salameche";
		listePokemon[1]="galopa";
		listePokemon[2]="magmar";
		listePokemon[3]="carapuce";
		listePokemon[4]="tartard";
		listePokemon[5]="leviator";
		listePokemon[6]="bulbizarre";
		listePokemon[7]="rafflesia";
		listePokemon[8]="empiflor";
		listePokemon[9]="pikachu";
		listePokemon[10]="voltali";
		
		id1 = rand.nextInt(11); // EN attendant le CSV on pick al�atoirement dans le tableau
		
		pokemonA=new Pokemon(listePokemon[id1]); // On cr�� ici 2 pok�mons
		return pokemonA;
	}
	
	public Interface1() throws IOException{  
			
			              
		    fenetre.setContentPane(new Panneau(pokemon[0],pokemon[1], anim ));
		    fenetre.setTitle("GLPOO");
		    fenetre.setResizable(false);
		    JPanel pan = new JPanel();
		    panel.setLayout( new FlowLayout());
		   	
		    
			// BOUTONS 
		    fenetre.setLayout(null);
		    
		    fenetre.add(atq1);
		    atq1.setBounds(30, 450, 150, 50);
		    atq1.addActionListener(this);
		  
		    fenetre.add(atq2);
		    atq2.setBounds(270, 450, 150, 50);
		    atq2.addActionListener(this);
		    
		    fenetre.add(atq3);
		    atq3.setBounds(510, 450, 150, 50);
		    atq3.addActionListener(this);
		    
		    fenetre.add(atq4);
		    atq4.setBounds(750, 450, 150, 50);
		    atq4.addActionListener(this);
		    
		    fenetre.add(atq5);
		    atq5.setBounds(990, 450, 150, 50);  
		    atq5.addActionListener(this);
		    
		      // AFFICHAVE COMPOSANTS TEXTES 
		      this.nom1 = new JLabel("Nom: " + pokemon[0].nomPokemon);
		      fenetre.getContentPane().add(nom1);
		      fenetre.add(nom1);
		      
		      this.nom2 = new JLabel("Nom: " + pokemon[1].nomPokemon);
		      fenetre.getContentPane().add(nom2);
		      fenetre.add(nom2);
		      
		      this.pv1.setText("PV: " + pokemon[0].PV);
		      fenetre.getContentPane().add(pv1);
		      this.fenetre.add(pv1);
		      
		      this.pv2.setText("PV: " + pokemon[1].PV);
		      fenetre.getContentPane().add(pv2);
		      fenetre.add(pv2);
		      
		      this.type1 = new JLabel("Type: ");
		      fenetre.getContentPane().add(type1);
		      fenetre.add(type1);
		      
		      this.type2 = new JLabel("Type: ");
		      fenetre.getContentPane().add(type2);
		      fenetre.add(type2);
		      
		      this.mana1.setText("Mana: "+pokemon[0].mana);
		      fenetre.getContentPane().add(mana1);
		      fenetre.add(mana1);
		      
		      this.mana2.setText("Mana: "+pokemon[1].mana);
		      fenetre.getContentPane().add(mana2);
		      fenetre.add(mana2);
		      
		      this.tour.setText("C'est à "+pokemon[0].nomPokemon+" de jouer !");
		      fenetre.add(tour);
		      
		      fenetre.add(actions);
		      
		      describ1= new JTextArea("L'attaque de base retire la valeur \n de la première boule du tirage \n aux PV de l'adversaire. \n Cette attaque ne consomme \n pas de mana. \n Le type électrique inflige \n des dégats supplémentaires");
		      describ1.setEnabled(false);
		      describ1.setForeground(black);
		      fenetre.add(describ1);
		      
		      describ2= new JTextArea("La compétence vous soigne \n d'un nombre de PV \n égal à la valeur de la 2e boule du tirage \n Cette compétence consomme la \n même valeur en mana.\n Le type eau bénéficie de soins \n supplémentaires");
		      describ2.setEnabled(false);
		      describ2.setForeground(black);
		      fenetre.add(describ2);
		      
		      describ3= new JTextArea("La compétence retire la valeur \n de la 3eme boule du tirage aux \n dégats de l'attaque de base\n de l'advesaire. \n Cette compétence consomme la \n même valeur en mana.\n Le type plante diminue davantage \n l'attaque de base");
		      describ3.setEnabled(false);
		      describ3.setForeground(black);
		      fenetre.add(describ3);
		      
		      describ4= new JTextArea("La compétence inflige 2 fois \n de la valeur de la 4eme boule \n du tirage à l'advesaire. \n Cette compétence consomme la \n même valeur en mana.\n Le type feu inflige davantage \n de dégats");
		      describ4.setEnabled(false);
		      describ4.setForeground(black);
		      fenetre.add(describ4);
		      
		      describ5= new JTextArea("La compétence régénère votre\n mana et les dégats de votre\n attaque de base. Le mana est \n regénéré d'un montant égal à\n la valeur de la 5e boule du tirage\n plus 10.\n Ajoute aussi 10 à l'attaque de base.\n Si l'attaque de base est 0,\n alors elle récupère l'intégralité\n de ses dégats, moins la\n valeur de la 5e boule du tirage.");
		      describ5.setEnabled(false);
		      describ5.setForeground(black);
		      fenetre.add(describ5);
		      
		      fenetre.add(tirage1);
		      fenetre.add(tirage2);
		      
		      // AFFICHAGE PV POKEMON 1 
		      nom1.setBounds(200,130,100,100);
		      pv1.setBounds(110,200,100,100);
		      type1.setBounds(110,160,100,100);
		      mana1.setBounds(110,220,100,100);
		      
		      nom2.setBounds(750,130,100,100);
		      pv2.setBounds(1000,200,100,100);
		      type2.setBounds(1000,160 , 100 , 100);
		      mana2.setBounds(1000,220,100,100);
		      
		      describ1.setBounds(13,520,190,200);
		      describ2.setBounds(250,520,190,200);
		      describ3.setBounds(493,520,190,200);
		      describ4.setBounds(730,520,190,200);
		      describ5.setBounds(980,520,193,200);
		      tirage1.setForeground(white);
		      tirage2.setForeground(white);
		      tirage1.setBounds(5, 5, 500, 50);
		      tirage2.setBounds(5, 20, 500, 50);
		      actions.setBounds(450, 400, 800, 50);
		      tour.setBounds(510, 150, 500, 50);
		      
		    afficherCaract();
		    
		    fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    fenetre.setSize(1200, 800);
		    fenetre.setVisible(true);
		   
		    
		    
			
		    
		    
		}
	

	  public void afficherCaract ()
	  {
		  
		  System.out.println(pokemon[0].nomPokemon);
		  System.out.print("HP:");
		  System.out.println(pokemon[0].PV);
		  System.out.print("mana:");
		  System.out.println(pokemon[0].mana);
		  System.out.print("type:");
		  System.out.println(pokemon[0].type);
		  System.out.print("faiblesse:");
		  System.out.println(pokemon[0].faiblesses);
		  System.out.println();
		  System.out.println(pokemon[1].nomPokemon);
		  System.out.print("HP:");
		  System.out.println(pokemon[1].PV);
		  System.out.print("mana:");
		  System.out.println(pokemon[1].mana);
		  System.out.print("type:");
		  System.out.println(pokemon[1].type);
		  System.out.print("faiblesse:");
		  System.out.println(pokemon[1].faiblesses);
		  
		 // System.out.println(pokemon1.attaques.coutMana_attaque1);
	  }
	  
	  public void actionPerformed(ActionEvent e) {	    
		   
		  
		  if(e.getSource() == atq1)
		  {
			  
			  System.out.println();
			  
			  pokemon[a].attaques.lancerAttaque1(pokemon[a], pokemon[b]); 
			  afficherCaract();
			  tmp=a;
			  a=b;
			  b=tmp;
			  action = 1;
		
			  
			  
		  }
		  if(e.getSource() == atq2)
		  {
			  if(pokemon[a].mana-pokemon[a].attaques.attaque2>0)
			  {
				  pokemon[a].attaques.lancerAttaque2(pokemon[a], pokemon[b]); 
				 
				  tmp=a;
				  a=b;
				  b=tmp;
			
			  }
			  else action = 6;
			  
			  action = 2;
		  }
		  if(e.getSource() == atq3)
		  {
			  System.out.println();
			 
			  pokemon[a].attaques.lancerAttaque3(pokemon[a], pokemon[b]); 
			 
			  tmp=a;
			  a=b;
			  b=tmp;
			  action = 3;
		
		  }
		  if(e.getSource() == atq4)
		  {
			  if(pokemon[a].mana-pokemon[a].attaques.attaque4>0)
			  {
				  System.out.println();
				 
				  pokemon[a].attaques.lancerAttaque4(pokemon[a], pokemon[b]); 
				  
				  tmp=a;
				  a=b;
				  b=tmp;
				  action=4;
				
			  }
			  else action = 6;
		  }
		  if(e.getSource() == atq5)
		  {
			  System.out.println();
			 
			  pokemon[a].attaques.lancerAttaque5(pokemon[a], pokemon[b]); 
			  
			  tmp=a;
			  a=b;
			  b=tmp;
			  action = 5;
			 
		  }
		  if(pokemon[a].PV<=0 ) //|| pokemon[b].PV<=0 )
		  {
			  
			  try {
		    	    Thread.sleep(2000);                 //1000 milliseconds is one second.
		    	} catch(InterruptedException ex) {
		    	    Thread.currentThread().interrupt();
		    	}
			  JOptionPane.showMessageDialog(fenetre,
					    pokemon[b].nomPokemon+" a gagné !!",
					    "Vainqueur",
					    JOptionPane.PLAIN_MESSAGE);
			  System.exit(EXIT_ON_CLOSE);
		  }
		  if(pokemon[b].PV<=0 ) //|| pokemon[b].PV<=0 )
		  {
			  
			  try {
		    	    Thread.sleep(2000);                 //1000 milliseconds is one second.
		    	} catch(InterruptedException ex) {
		    	    Thread.currentThread().interrupt();
		    	}
			  JOptionPane.showMessageDialog(fenetre,
					    pokemon[a].nomPokemon+" a gagné !!",
					    "Vainqueur",
					    JOptionPane.PLAIN_MESSAGE);
			  System.exit(EXIT_ON_CLOSE);
		  }
		 // afficherCaract();
		  if(pokemon[0].mana < 0)
	    		pokemon[0].mana=0;
	    		  
	      if (pokemon[1].mana < 0)
	     		pokemon[1].mana=0;
		  
		  
		  pv1.removeAll();
	      pv1.validate();//valider le suppression
	      this.pv1.setText("PV: " + pokemon[0].PV); 
	      pv1.revalidate();
	      pv1.repaint();
		  
		  pv2.removeAll();
	      pv2.validate();//valider le suppression
	      this.pv2.setText("PV: " + pokemon[1].PV); 
	      pv2.revalidate();
	      pv2.repaint();
	      
	      mana1.removeAll();
	      mana1.validate();//valider le suppression
	      this.mana1.setText("Mana: " + pokemon[0].mana); 
	      mana1.revalidate();
	      mana1.repaint();
		  
	      mana2.removeAll();
	      mana2.validate();//valider le suppression
	      this.mana2.setText("Mana: " + pokemon[1].mana); 
	      mana2.revalidate();
	      mana2.repaint();
	      
	      actions.removeAll();
	      actions.validate();
	      if(action == 1)
	    	  this.actions.setText(pokemon[b].nomPokemon+" a infligé "+pokemon[b].attaques.attaque1+" points de dégats à "+pokemon[a].nomPokemon);
	      if(action == 2)
	    	  this.actions.setText(pokemon[b].nomPokemon+" s'est soigné de "+pokemon[b].attaques.attaque2+" points de vie ");
	      if(action == 3)
	    	  this.actions.setText(pokemon[b].nomPokemon+" a réduit de "+pokemon[b].attaques.attaque3+" l'attaque de base de "+pokemon[a].nomPokemon);
	      if(action == 4)
	    	  this.actions.setText(pokemon[b].nomPokemon+" a infligé "+pokemon[b].attaques.attaque4+" points de dégats à "+pokemon[a].nomPokemon);
	      if(action == 5)
	    	  this.actions.setText(pokemon[b].nomPokemon+" gagne "+(pokemon[b].attaques.attaque5+10)+" points de mana et son attaque de base est augmentée");
	      if(action == 6)
	    	  this.actions.setText("Vous n'avez plus de mana !");
		  
	      actions.revalidate();
	      actions.repaint();
	      
	      pokemon[0].attaques.reinitialiser(pokemon[0]);
	      pokemon[1].attaques.reinitialiser(pokemon[1]);
	      
	      try {
	    	    Thread.sleep(500);                 //1000 milliseconds is one second.
	    	} catch(InterruptedException ex) {
	    	    Thread.currentThread().interrupt();
	    	}
	      tour.removeAll();
	      tour.validate();
	      this.tour.setText("C'est à "+pokemon[a].nomPokemon+" de jouer !");
	      tour.revalidate();
	      tour.repaint();
	      
	  }  
}