package Interface;

import javax.swing.JLabel;

import pokemon.Pokemon;

public class Textes {

	Textes(Pokemon pok1, Pokemon pok2)
	{
		
	}
}
