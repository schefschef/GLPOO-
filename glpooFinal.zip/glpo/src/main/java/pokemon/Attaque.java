package pokemon;

import java.util.List;

import csv.Boules;
import csv.csvAttaque;

public class Attaque {

	public int attaque1;
	public int attaque2;
	public int attaque3;
	public int attaque4;
	public int attaque5;
	public int bonusAttaque1;
	public int bonusAttaque2;
	
	private int tmp1, tmp2, tmp3, tmp4, tmp5;
	
	
	public Attaque( int atq1, int atq2, int atq3, int atq4, int atq5, int bo1, int bo2)
	{
		
		this.attaque1= tmp1= atq1;
		this.attaque2= tmp2= atq2;
		this.attaque3= tmp3= atq3;
		this.attaque4= tmp4= atq4;
		this.attaque5= tmp5= atq5;
		this.bonusAttaque1=bo1;
		this.bonusAttaque2=bo2;
		
				
	}
	
	// DEGATS BASIQUES, ELEC FAIT PLUS DE DEGATS BASIQUES
	public void lancerAttaque1( Pokemon pok1, Pokemon pok2 )
	{
		
		
		
		
		if(pok1.type == "elec")
			pok1.attaques.attaque1+=this.attaque1; 
		
		if(pok1.type==pok2.faiblesses)
		{
			
			pok1.attaques.attaque1 += ((2/3)*this.attaque1);
		}
		
		if(pok2.resistances==pok1.type)
			pok1.attaques.attaque1 -= ((2/3)*this.attaque1);
		
		
		pok2.PV -= pok1.attaques.attaque1;
		
		
	//attaque1+=this.attaque1+this.bonusAttaque1;
		
		System.out.print("l'attaque a infligé: ");
		System.out.print(this.attaque1);
		System.out.print(" à ");
		System.out.println(pok2.nomPokemon);
		
		
	}
	// SOINS, EAU FAIT PLUS DE SOINS ET SI -50 PTS DE VIE SOINS + 100%
	public void lancerAttaque2( Pokemon pok1, Pokemon pok2 )
	{
		
		if(pok1.type=="eau")
		{
			
			if(pok1.PV<50)
			{
				pok1.attaques.attaque2+=this.attaque2;
			}else pok1.attaques.attaque2+=(1/3)*this.attaque2;
		}
		if(pok1.PV+pok1.attaques.attaque2>200)
			pok1.PV =200;
		else
			pok1.PV += pok1.attaques.attaque2;
		
		pok1.mana -= pok1.attaques.attaque2;
		
		System.out.print("la compétence a soigné de: ");
		System.out.print(this.attaque2);
		System.out.print(" ");
		System.out.println(pok1.nomPokemon);
		
	}
	//REDUCTION DE L'ATTAQUE DE BASE DE L'ENNEMI, HERBE FAIT PLUS DE REDUC
	public void lancerAttaque3( Pokemon pok1, Pokemon pok2 )
	{
	
		
		if(pok1.type=="herbe")
			pok1.attaques.attaque3+=(this.attaque3*1/3);
		
		if((pok2.attaques.attaque1-pok1.attaques.attaque3)<0 )
			pok2.attaques.attaque1=0;
		
		pok2.attaques.attaque1 -= pok1.attaques.attaque3;
		if(pok2.attaques.attaque1<0)
			pok2.attaques.attaque1=0;
		
		System.out.print("l'attaque a réduit l'attaque DE BASE de l'adversaire de: ");
		System.out.print(this.attaque3);
		System.out.print(" à ");
		System.out.println(pok2.nomPokemon);
		
	}
	//ATTAQUE PUISSANTE, FEU FAIT PLUS DE DEGAT MAIS PERD PLUS DE MANA
	public void lancerAttaque4( Pokemon pok1, Pokemon pok2 )
	{
		
		pok1.attaques.attaque4*=2;
		
		if(pok1.type == "feu")
			pok1.attaques.attaque4+=((2/3)*this.attaque4);
		
		if(pok1.type==pok2.faiblesses)
			pok1.attaques.attaque4 += ((2/3)*this.attaque4);
		
		if(pok2.resistances==pok1.type)
			pok1.attaques.attaque4 -= ((2/3)*this.attaque4);
		
		
		pok2.PV -= pok1.attaques.attaque4;
		pok1.mana -= pok1.attaques.attaque4;
		System.out.print("l'attaque a infligé: ");
		System.out.print(this.attaque4);
		System.out.print(" à ");
		System.out.println(pok2.nomPokemon);
		System.out.print("et a couté en mana: ");
		System.out.println(this.attaque4);
		
	} 
	// REGEN MANA ET ATTAQUE DE BASE
	public void lancerAttaque5( Pokemon pok1, Pokemon pok2 )
	{
		pok1.mana += 10+this.attaque5+this.bonusAttaque2;
		
		pok1.attaques.attaque1+=(this.attaque5+20);
	}
	
	public void reinitialiser(Pokemon pok1)
	{
		//pok1.attaques.attaque1= tmp1;
		pok1.attaques.attaque2= tmp2;
		pok1.attaques.attaque3= tmp3;
		pok1.attaques.attaque4= tmp4;
		pok1.attaques.attaque5= tmp5;
	}
	
}
