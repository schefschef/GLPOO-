package Interface;

import static org.junit.Assert.*;

import org.junit.Test;

public class JeuTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
