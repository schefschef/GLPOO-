package Interface;

import static org.junit.Assert.*;

import org.junit.Test;

public class TextesTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
