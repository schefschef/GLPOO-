package Interface;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


import pokemon.Pokemon;


@SuppressWarnings("serial")
public class Panneau extends JPanel{
	
	private Pokemon poke1, poke2;
	private Image pok1Type, pok2Type;
	private int anim;

	
	public Panneau(Pokemon pok1, Pokemon pok2, int a) throws IOException {
		this.poke1=pok1;
		this.poke2=pok2;
		if(pok1.type=="feu")
			this.pok1Type = ImageIO.read(new File("feu.png"));
		if(pok1.type=="elec")
			this.pok1Type = ImageIO.read(new File("elec.png"));
		if(pok1.type=="eau")
			this.pok1Type = ImageIO.read(new File("eau.png"));
		if(pok1.type=="herbe")
			this.pok1Type = ImageIO.read(new File("herbe.png"));
		if(pok2.type=="feu")
			this.pok2Type = ImageIO.read(new File("feu.png"));
		if(pok2.type=="elec")
			this.pok2Type = ImageIO.read(new File("elec.png"));
		if(pok2.type=="eau")
			this.pok2Type = ImageIO.read(new File("eau.png"));
		if(pok2.type=="herbe")
			this.pok2Type = ImageIO.read(new File("herbe.png"));
		
		this.anim =a ;
	}

	@SuppressWarnings("unused")
	public void paintComponent(Graphics g){
		
	    try {
	      Image img = ImageIO.read(new File("fond.png"));
	      Image cadre = ImageIO.read(new File("cadre.png"));
	      Image cadre2 = ImageIO.read(new File("cadre.png"));
	      Image cadre3 = ImageIO.read(new File("cadre2.png"));
	      Image pokeGauche = ImageIO.read(new File(poke1.nomImage));
	      Image pokeDroite = ImageIO.read(new File(poke2.nomImage));
	      
	      //Position des images
	      g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this);
	      g.drawImage(cadre, 200, 200, this);
	      g.drawImage(cadre2, 750, 200, this);
	      g.drawImage(pokeDroite, 750, 200, this);
	      g.drawImage(pokeGauche, 200, 200, this);
	      g.drawImage(this.pok1Type, 150, 200, this);
	      g.drawImage(this.pok2Type, 1050, 200, this);
	      
	      
	      
	    } catch (IOException e) {
	      e.printStackTrace();
	    }                
	  }               
}