package pokemon;

import java.util.List;
import java.util.Random;

import csv.Boules;
import csv.csvAttaque;

public class Pokemon {
	
	public String nomImage;
	public boolean tour;
	public String nomPokemon; 
	public String type;
	public String resistances;
	public String faiblesses;
	public int PV;
	public int mana;
	public boolean etat;
	public int armure;
	public boolean shield;
	
	
	final Boules tirage = new csvAttaque();
	final List<Attaque> boules = tirage.getAttaque();
	public Attaque attaques;
	
	//private static 
	
	public Pokemon( String nom )
	{
		Random rand = new Random();
		int ligne; 
		ligne = rand.nextInt(217)+2;
		System.out.println(ligne);
		System.out.println();
		this.shield = false;
		this.etat =true;
		this.PV = 200;
		this.mana = 70;
		this.armure = 10;
		this.nomPokemon=nom;
		if ( nom =="salameche" || nom=="galopa" || nom=="magmar")
		{
			this.type="feu";
			this.resistances="herbe";
			this.faiblesses="eau";
		}
		if ( nom =="carapuce" || nom=="tartard" || nom=="leviator")
		{
			this.type="eau";
			this.resistances="feu";
			this.faiblesses="herbe";
		}
		if ( nom =="bulbizarre" || nom=="rafflesia" || nom=="empiflor")
		{
			this.type="herbe";
			this.resistances="eau";
			this.faiblesses="feu";
		}
		if ( nom =="pikachu" || nom=="voltali")
		{
			this.type="elec";
			this.resistances="elec";
			this.faiblesses="eau";
		}
		nomImage=nom +".png";
		
		
		if(this.type=="eau")
			this.mana=80;
		
		attaques= boules.get(ligne);
	}
	
	
}
