package csv;



import java.util.ArrayList;

import java.util.List;
import static csv.CsvFileHelper.readCsvFile;
import pokemon.Attaque;



public class csvAttaque implements Boules {

	private final static char SEPARATOR = ';';
	private final static String RESOURCES_PATH = "src/main/resources/";
	private final static String CSV_FILE_NAME = "euromillions.csv";

	public List<Attaque> getAttaque() {

		final List<String[]> data = readCsvFile(RESOURCES_PATH + CSV_FILE_NAME, SEPARATOR);

		final List<Attaque> boules = getData(data);

		return boules;
	}

	private List<Attaque> getData(List<String[]> data) {
		final List<Attaque> boules = new ArrayList<Attaque>();

		try {
			
			for(String[] oneData : data)
			{
				if(oneData[4].equals("boule_1")){}
				else{
				
					boules.add(new Attaque(Integer.parseInt(oneData[4]), Integer.parseInt(oneData[5]), Integer.parseInt(oneData[6]),Integer.parseInt(oneData[7]),Integer.parseInt(oneData[8]),Integer.parseInt(oneData[9]),Integer.parseInt(oneData[10])));
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return boules;
	}

}