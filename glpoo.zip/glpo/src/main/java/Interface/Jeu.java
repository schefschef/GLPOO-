package Interface;

import javax.swing.JFrame;

@SuppressWarnings({ "unused", "serial" })
public class Jeu extends Interface1 {
	public static void main(String[] args){

		Interface1 fen = new Interface1();
	}
}

